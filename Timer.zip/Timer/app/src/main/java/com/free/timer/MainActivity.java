package com.free.timer;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button button;

    public static final String SHARED_PREFS = "sharedpreferences";
    String timeValue = "timeValue";

    EditText timerInput;
    int time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timerInput = findViewById(R.id.timerInput);

        button = findViewById(R.id.startBtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                start();
            }
        });

    }

    public void start(){

        if(!timerInput.getText().toString().isEmpty()){

            SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();

            editor.putString(timeValue, timerInput.getText().toString());
            editor.commit();

            Intent intent = new Intent(this,timerpage.class);
            startActivity(intent);

        }else{

            Toast.makeText(getApplicationContext(),"", Toast.LENGTH_LONG).show();

        }


    }

}
